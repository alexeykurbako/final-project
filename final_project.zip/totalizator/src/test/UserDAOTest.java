

import com.epam.totalizator.exceptions.DaoException;
import org.junit.*;

public class UserDAOTest {
    @Test
//    public void getUserByLoginAndPassTest(){
//        Optional<User> actual = null;
//        User ss = new User(4, "alex","alex@gmail.com", "1234", new BigDecimal(0), Role.user);
//        Optional<User> exepted = Optional.of(ss);
//        UserDaoImpl dao = new UserDaoImpl();
//        try {
//            actual = dao.findUserByLoginAndPassword("alex","1234");
//            System.out.println(ss.getLogin());
//            System.out.println(actual.get().getLogin());
//        } catch (DaoException exc){
//            //log
//        }
//
//
//        Assert.assertEquals(exepted.get(),ss);
//    }
//    public void loginTest(){
//        UserService service = new UserService();
//
//            Optional<User> actual = service.login("alex", "1234");
//            boolean iss = actual.isPresent();
//
//                //System.out.println(actual.get().getLogin());
//        //System.out.println(actual.get().getPassword());
//
//
//        Assert.assertEquals(true,iss);
//    }

    public void insertTest() throws DaoException {


        //System.out.println(actual.get().getLogin());
        //System.out.println(actual.get().getPassword());


        Assert.assertEquals(true,true);
    }
}
