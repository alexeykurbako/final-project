package com.epam.totalizator.dao;

import com.epam.totalizator.exceptions.DaoException;

import java.util.List;
import java.util.Optional;

public interface Dao<T> {
    Optional<T> getById(long id) throws DaoException;
    List<T> getAll() throws DaoException;
    void save(T object) throws DaoException;
    void removeById(T object) throws DaoException;

}
