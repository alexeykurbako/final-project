package com.epam.totalizator.entity;

public interface Entity {
    long getId();
}
