package com.epam.totalizator.entity;

public enum Language {
    EN, RU, BY
}
