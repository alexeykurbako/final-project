package com.epam.totalizator.dao.impl;

import com.epam.totalizator.builder.impl.CompetitionBuilder;
import com.epam.totalizator.dao.AbstractDAO;
import com.epam.totalizator.dao.CompetitionDao;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class CompetitionDaoImpl extends AbstractDAO<Competition> implements CompetitionDao {
    private static final Logger LOGGER = LogManager.getLogger (CompetitionDaoImpl.class);

    private static final String GET_ALL_FINISHED = "SELECT competition_id FROM competition WHERE status = 'finish'";

    private static final String SAVE_COMPETITION = "INSERT INTO totalizator.competition(first_team_id, second_team_id) VALUES (?,?)";

    private static final String GET_FINISHED_COMPETITION_BY_USER_AND_EVENT = "SELECT competition.competition_id, t1.name, t2.name, status, team_first_result, team_second_result FROM competition " +
            " JOIN event e on competition.competition_id = e.competition_id " +
            " JOIN bet b on e.event_id = b.event_id " +
            " JOIN team t1 ON competition.first_team_id = t1.team_id " +
            " JOIN team t2 ON competition.second_team_id = t2.team_id " +
            " WHERE b.event_id = ? AND b.user_id = ? AND competition.status = 'finish' AND b.was_payed = 'false';";

    private static final String REMOVE_BY_ID = "DELETE competition_id, first_team_id, second_team_id, status, team_first_result, second_team_result  FROM totalizator.competition WHERE competition_id = ?";

    private static final String GET_COMPETITION_BY_TEAMS = "SELECT competition.competition_id, t1.name, t2.name, status, team_first_result, team_second_result from competition " +
            "JOIN team t1 on competition.first_team_id = t1.team_id " +
            "JOIN team t2 on competition.second_team_id = t2.team_id " +
            "WHERE t1.name = ? AND t2.name = ? ;";


    public CompetitionDaoImpl(Connection connection) {
        super.connection = connection;
    }

    @Override
    protected void prepareUpdateStatement(PreparedStatement preparedStatement, String... paramss) throws DaoException {

    }

    @Override
    protected void prepareRemoveStatement(PreparedStatement preparedStatement, Competition object) throws DaoException {
        try {
            preparedStatement.setLong (1, object.getId());
        } catch (SQLException e) {
            LOGGER.error ("exception in prepareRemoveStatement in  implementation of CompetitionDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareExecuteStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
            for(int i = 0; i < params.length; i++){
                preparedStatement.setString (i + 1, params[i]);
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementInserts in  implementation of CompetitionDao class ", e);
        }
    }

    @Override
    protected void prepareInsertStatement(PreparedStatement preparedStatement, Competition object) throws DaoException {
        try {
            preparedStatement.setLong (1, object.getFirstTeam().getId());
            preparedStatement.setLong (2, object.getSecondTeam().getId());
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementInserts in  implementation of CompetitionDao class ", e);
        }
    }

    @Override
    public Optional<Competition> getById(long id) throws DaoException {
        return Optional.empty();
    }

    @Override
    public List<Competition> getAll() throws DaoException {
        return null;
    }

    @Override
    public void save(Competition object) throws DaoException {
        executeInsert(SAVE_COMPETITION, object);
    }

    @Override
    public void removeById(Competition object) throws DaoException {
        executeRemove(REMOVE_BY_ID, object);
    }

    @Override
    public List<Competition> getAllFinished() {
        return null;
    }

    @Override
    public Optional<Competition> getFinishedCompetitionByUserIdAndEventId(long eventId, long userId) throws ServiceException {
        List<Competition> list = null;
        try {
            String currentEventId = String.valueOf(eventId);
            String currentUserId = String.valueOf(userId);
            list = executeQuery(GET_FINISHED_COMPETITION_BY_USER_AND_EVENT, new CompetitionBuilder(), currentEventId, currentUserId);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
        return list.size () == 0 ? Optional.empty() :Optional.ofNullable(list.iterator().next());
    }

    @Override
    public Optional<Competition> getCompetitionByTeams(String firstName, String secondName) throws ServiceException {
        List<Competition> list = null;
        try {
            list = executeQuery(GET_COMPETITION_BY_TEAMS, new CompetitionBuilder(), firstName, secondName);
        } catch (DaoException e) {
            throw new ServiceException(e);
        }
        return list.size () == 0 ? Optional.empty() : Optional.ofNullable(list.iterator().next());
    }
}
