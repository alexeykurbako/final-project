package com.epam.totalizator.command.bet;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

public class ShowAddBetCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
        EventService eventService = new EventService();
        long id = Long.parseLong(request.getParameter("event_id"));
        Optional<Event> actual = eventService.getById(id);
        actual.ifPresent(event -> {
            Competition competition = event.getCompetition();
            Team firstTeam = competition.getFirstTeam();
            Team secondTeam = competition.getSecondTeam();
            double firstCoef = event.getFirstTeamCoefficient();
            double secondCoef = event.getSecondTeamCoefficient();
                request.setAttribute("event", event);
                request.setAttribute("first_team", firstTeam);
                request.setAttribute("second_team", secondTeam);
                request.setAttribute("first_coef", firstCoef);
                request.setAttribute("second_coef", secondCoef);
                request.setAttribute("isValid", true);
        });
        return new Respond (Respond.FORWARD, "/user_create_bet.jsp");
    }
}
