package com.epam.totalizator.command.user.bookmaker;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.Category;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.team.TeamService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class ShowBookmakerAddCommand implements Command {
    private static final Logger LOGGER = LogManager.getLogger(ShowBookmakerAddCommand.class);
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
        TeamService teamService = new TeamService();
        List<Team> teamList = teamService.getAll();
        List<Category> ctList = Arrays.asList(Category.values());
        request.setAttribute("categoryList", ctList);
        request.setAttribute("teamList", teamList);
        return new Respond (Respond.FORWARD, "/bookmaker_add.jsp");
    }
}
