package com.epam.totalizator.builder.impl;

import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.entity.Category;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.League;
import com.epam.totalizator.entity.Team;

import java.sql.ResultSet;
import java.sql.SQLException;

public class CompetitionBuilder implements Builder<Competition> {
    @Override
    public Competition build(ResultSet resultSet) throws SQLException {
            long id = resultSet.getLong("competition_id");
            String firstTeamName = resultSet.getString("t1.name");
            String secondTeamName = resultSet.getString("t2.name");
            Team firstTeam = buildTeam(firstTeamName);
            Team secondTeam = buildTeam(secondTeamName);
            String status = resultSet.getString("status");
            int firstTeamScore = resultSet.getInt("team_first_result");
            int secondTeamScore = resultSet.getInt("team_second_result");
            return new Competition(id, firstTeam, secondTeam, status, firstTeamScore, secondTeamScore);
    }

    public Team buildTeam(String name) {
        long id = 0;
        String teamName = name;
        String teamCategory = "football";
        League league = new League();
        return new Team(id, teamName, Category.valueOf(teamCategory.toUpperCase()), league);
    }


}
