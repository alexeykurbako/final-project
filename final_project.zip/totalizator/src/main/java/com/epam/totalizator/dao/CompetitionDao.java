package com.epam.totalizator.dao;

import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ServiceException;

import java.util.List;
import java.util.Optional;

public interface CompetitionDao extends Dao<Competition> {
    List<Competition> getAllFinished();
    Optional<Competition> getFinishedCompetitionByUserIdAndEventId(long eventId, long userId) throws ServiceException;
    Optional<Competition> getCompetitionByTeams(String firstName, String secondName) throws ServiceException;
}
