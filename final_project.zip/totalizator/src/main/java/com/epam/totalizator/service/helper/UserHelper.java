package com.epam.totalizator.service.helper;

import com.epam.totalizator.command.user.admin.LockUserCommand;
import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.UserDaoImpl;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.math.BigDecimal;
import java.util.Optional;

public class UserHelper {
    private static final Logger LOGGER = LogManager.getLogger (UserHelper.class);

    public void lockAction(long id) throws ServiceException {
        UserService service = new UserService();
        UserHelper helper = new UserHelper();
        Optional<User> user = service.getById(id);
        if (user.isPresent()) {
            if (user.get().isLocked()) {
                helper.unlock(user.get());
            } else {
                helper.lock(user.get());
            }
            service.update(user.get());
        } else {
            LOGGER.info("User with id:" + id + " doesn't exist");
        }
    }

    private void lock(User user){
        user.setLocked(true);
    }

    private void unlock(User user){
        user.setLocked(false);
    }

    public void subtractBetSize(User user, BigDecimal size) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            UserDaoImpl dao = factory.getUserDao();
            BigDecimal currentAccount = user.getMoney();
            BigDecimal finalAccount = currentAccount.subtract(size);
            user.setMoney(finalAccount);
            dao.update(user);
        }
    }
}
