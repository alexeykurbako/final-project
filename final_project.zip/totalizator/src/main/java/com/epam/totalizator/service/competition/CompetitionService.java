package com.epam.totalizator.service.competition;

import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.CompetitionDaoImpl;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.Optional;

public class CompetitionService {
    private static final Logger LOGGER = LogManager.getLogger(CompetitionService.class);

    public void saveCompetition(Competition competition) throws ServiceException {
        try(DaoFactory factory = new DaoFactory()) {
            CompetitionDaoImpl competitionDao = factory.getCompetitionDao();
            competitionDao.save(competition);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
    }

    public Optional<Competition> getFinishedCompetitionByUserIdAndEventId(long event_id, long currentUserId) throws ServiceException {
        try(DaoFactory factory = new DaoFactory()) {
            CompetitionDaoImpl competitionDao = factory.getCompetitionDao();
            return competitionDao.getFinishedCompetitionByUserIdAndEventId(event_id, currentUserId);
        }
    }

    public Optional<Competition> getCompetitionByTeams(String firstName, String secondName) throws ServiceException {
        try(DaoFactory factory = new DaoFactory()) {
            CompetitionDaoImpl competitionDao = factory.getCompetitionDao();
            return competitionDao.getCompetitionByTeams(firstName, secondName);
        }
    }
}
