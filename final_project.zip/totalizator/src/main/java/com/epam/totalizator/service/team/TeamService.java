package com.epam.totalizator.service.team;

import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.TeamDaoImpl;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Optional;

public class TeamService {
    private static final Logger LOGGER = LogManager.getLogger(TeamService.class);
    public List<Team> getAll() throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            TeamDaoImpl teamDao = factory.getTeamDao();
            return teamDao.getAll();
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public List<Team> getBothTeam(String firstName, String secondName) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            TeamDaoImpl teamDao = factory.getTeamDao();
            return teamDao.getBothTeam(firstName, secondName);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public Optional<Team> getTeamByName(String name) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            TeamDaoImpl teamDao = factory.getTeamDao();
            return teamDao.getTeamByName(name);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public Optional<Team> getTeamById(long id) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            TeamDaoImpl teamDao = factory.getTeamDao();
            return teamDao.getTeamById(id);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }

    }
}
