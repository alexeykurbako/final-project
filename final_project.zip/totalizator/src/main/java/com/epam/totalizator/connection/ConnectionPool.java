package com.epam.totalizator.connection;

import com.epam.totalizator.exceptions.ConnectionException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.locks.ReentrantLock;

public class ConnectionPool {
    private final static String URL = "jdbc:mysql://127.0.0.1:3306/totalizator?serverTimezone=Europe/Minsk";
    private final static String USERNAME = "root";
    private final static String PASSWORD = "admin";
    private final static Logger LOGGER = LogManager.getLogger(ConnectionPool.class);
    private static final ConnectionPool POOL = new ConnectionPool();
    private final static int poolSize = 25;

    private ArrayBlockingQueue<Connection> connections;
    private ReentrantLock lockForReturnConnection;

    public static ConnectionPool getConnectionPool(){
        return POOL;
    }

    private ConnectionPool()  {
        connections = new ArrayBlockingQueue<>(poolSize);
        lockForReturnConnection = new ReentrantLock();

        for(int i = 0; i < poolSize; i++){
            Connection connection;
            try  {
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
                connections.offer(connection);
            }
            catch (SQLException exc){
                LOGGER.error(exc);
            }
        }
    }

    public Connection getConnection() {
        Connection connection;
        try {
            connection = connections.take();
        }
        catch(InterruptedException exc){
            LOGGER.error(exc);
            throw new ConnectionException(exc);
        }
        return connection;
    }

    public void returnConnectionToPool(Connection connection){
        lockForReturnConnection.lock();
        if(!connections.contains(connection)) {
            connections.offer(connection);
        }
        lockForReturnConnection.unlock();
    }

    public void closeAll() {
        for(Connection connection : connections){
            try {
                connection.close();
            } catch (SQLException e) {
                LOGGER.error(e);
                throw new ConnectionException(e);
            }
        }
    }
}
