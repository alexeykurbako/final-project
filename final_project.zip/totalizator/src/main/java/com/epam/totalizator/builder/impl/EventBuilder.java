package com.epam.totalizator.builder.impl;

import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.entity.*;

import java.sql.ResultSet;
import java.sql.SQLException;

public class EventBuilder implements Builder<Event> {
    @Override
    public Event build(ResultSet resultSet) throws SQLException {
        long event_id = resultSet.getLong("event_id");
        Category category = Category.valueOf(resultSet.getString("category.name").toUpperCase());
        String firstTeamName = resultSet.getString("t1.name");
        String secondTeamName = resultSet.getString("t2.name");
        double firstCoef = Double.parseDouble(resultSet.getString("first_team_coefficient"));
        double secondCoef = Double.parseDouble(resultSet.getString("second_team_coefficient"));
        String firstLeagueName = resultSet.getString("l1.name");
        String secondLeagueName = resultSet.getString("l2.name");
        League firstTeamLeague = buildLeague(firstLeagueName);
        League secondTeamLeague = buildLeague(secondLeagueName);
        Competition competition = buildCompetition(firstTeamName,secondTeamName,category,firstTeamLeague,secondTeamLeague);
        return new Event(event_id, competition, firstCoef, secondCoef);

    }

    private League buildLeague(String name){
        return new League(0,name);
    }


    private Team buildTeam(String name, Category category, League league) {
        long team_id = 0;
        String teamName = name;
        Category teamCategory = category;
        League teamLeague = league;
        return new Team(team_id, teamName, teamCategory, league);
    }

    private Competition buildCompetition(String firstTeamName, String secondTeamName, Category category, League firstLeague, League secondLeague){
        long id = 0;
        Team firstTeam = buildTeam(firstTeamName, category, firstLeague);
        Team secondTeam = buildTeam(secondTeamName, category, secondLeague);
        String status = "new";
        int firstTeamScore = 0;
        int secondTeamScore = 0;
        return new Competition(id, firstTeam, secondTeam, status, firstTeamScore, secondTeamScore);
    }

}
