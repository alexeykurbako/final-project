package com.epam.totalizator.dao;

import com.epam.totalizator.dao.Dao;
import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;

import java.util.List;
import java.util.Optional;

public interface EventDao extends Dao<Event> {
    List<Event> getAllActiveEvents() throws DaoException;
    Optional<Event> getEventByUserIdAndEventId(long eventId, long userId) throws ServiceException;
    void finishEvent(String... params) throws DaoException;
    List<Event> getFinishedEventByUser(User user) throws DaoException;
}
