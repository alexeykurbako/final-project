package com.epam.totalizator.builder.impl;

import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.entity.User;


import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BetBuilder implements Builder<Bet> {
    @Override
    public Bet build(ResultSet resultSet) throws SQLException {
        long betId = resultSet.getLong("bet_id");
        long userId = resultSet.getLong("user_id");
        long eventId = resultSet.getLong("event_id");
        long teamId = resultSet.getLong("team_id");
        BigDecimal size = resultSet.getBigDecimal("size");
        return new Bet(betId, userId, eventId, teamId, size);
    }
}
