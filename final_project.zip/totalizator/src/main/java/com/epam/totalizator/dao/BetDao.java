package com.epam.totalizator.dao;

import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;

import java.util.List;
import java.util.Optional;

public interface BetDao extends  Dao<Bet>{
    List<Bet> getNotPayedBets() throws DaoException;
    void changeBetStatus(Bet bet) throws ServiceException, DaoException;
    List<Bet> getBetsByFinishedEvents(User user) throws DaoException;
}
