package com.epam.totalizator.builder.impl;
import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.entity.Category;
import com.epam.totalizator.entity.League;
import com.epam.totalizator.entity.Team;

import java.sql.ResultSet;
import java.sql.SQLException;

public class TeamBuilder implements Builder<Team> {
    @Override
    public Team build(ResultSet resultSet) throws SQLException {
        long id = resultSet.getLong("team.team_id");
        String teamName = resultSet.getString("team.name");
        String teamCategory = resultSet.getString("category.name");
        String teamLeagueName = resultSet.getString("league.name");
        League league = buildLeague(teamLeagueName);
        return new Team(id, teamName, Category.valueOf(teamCategory.toUpperCase()), league);
    }

    private League buildLeague(String name) {
        return new League(0, name);
    }
}
