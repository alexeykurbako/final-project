package com.epam.totalizator.service.helper;

import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.bet.BetService;
import com.epam.totalizator.service.competition.CompetitionService;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.team.TeamService;
import com.epam.totalizator.service.user.UserService;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class BetCalculator {
    public void calculateBets(int firstTeamResult, int secondTeamResult, long event_id) throws ServiceException {
        BetService betService = new BetService();
        UserService userService = new UserService();
        CompetitionService competitionService = new CompetitionService();
        EventService eventService = new EventService();
        eventService.finishEvent(firstTeamResult, secondTeamResult, event_id);
        BetCalculator calculator = new BetCalculator();
        List<Bet> betList = betService.getNotPayedBets();
        for(Bet bet: betList){
            Optional<User> actualUser = userService.getById(bet.getUserId());
            actualUser.ifPresent(user -> {
                long currentUserId = user.getId();
                try {
                    Optional<Event> event = eventService.getEventByUserIdAndEventId(event_id, currentUserId);
                    Optional<Competition> competition = competitionService.getFinishedCompetitionByUserIdAndEventId(event_id, currentUserId);
                    if(event.isPresent() && competition.isPresent()){
                        Event currentEvent = event.get();
                        Competition currentCompetition = competition.get();
                        calculator.calculatePayment(user, currentEvent, currentCompetition, bet.getChosenTeamId(), bet.getSize());
                        userService.update(user);
                        betService.changeBetStatus(bet);
                    }
                } catch (ServiceException e) {
                    e.printStackTrace();
                }
            });
        }
    }

    private void calculatePayment(User currentUser, Event currentEvent, Competition currentCompetition, long chosenTeamId, BigDecimal betSize) throws ServiceException {
        TeamService teamService = new TeamService();
        String firstTeamName = currentCompetition.getFirstTeam().getTeamName();
        String secondTeamName = currentCompetition.getSecondTeam().getTeamName();
        Optional<Team> actualFirstTeam = teamService.getTeamByName(firstTeamName);
        Optional<Team> actualSecondTeam = teamService.getTeamByName(secondTeamName);

        long firstTeamId = 0;
        long secondTeamId = 0;
        long winnerTeamId;
        double payCoefficient = 0;

        if(actualFirstTeam.isPresent() && actualSecondTeam.isPresent()){
            Team firstTeam = actualFirstTeam.get();
            Team secondTeam = actualSecondTeam.get();
            firstTeamId = firstTeam.getId();
            secondTeamId = secondTeam.getId();
        }

        int firstTeamResult = currentCompetition.getFirstTeamScore();
        int secondTeamResult = currentCompetition.getSecondTeamScore();

        if(firstTeamResult > secondTeamResult){
            winnerTeamId = firstTeamId;
            payCoefficient = currentEvent.getFirstTeamCoefficient();
        } else if(firstTeamResult < secondTeamResult){
            winnerTeamId = secondTeamId;
            payCoefficient = currentEvent.getSecondTeamCoefficient();
        } else {
            winnerTeamId = 0;
        }

        if(winnerTeamId == chosenTeamId){
            payMoneyForWin(payCoefficient,currentUser, betSize);
        }
        if(winnerTeamId == 0){
            payMoneyForDraw(currentUser, betSize);
        }
    }

    private void  payMoneyForWin(double payCoefficient, User user, BigDecimal size){
        BigDecimal currentAccount = user.getMoney();
        BigDecimal castedPayCoefficient = BigDecimal.valueOf(payCoefficient);
        BigDecimal finalAccount = currentAccount.add(size
                .multiply(castedPayCoefficient));
        user.setMoney(finalAccount);
    }

    private void  payMoneyForDraw(User user, BigDecimal size){
        BigDecimal currentAccount = user.getMoney();
        BigDecimal finalAccount = currentAccount.add(size);
        user.setMoney(finalAccount);
    }
}
