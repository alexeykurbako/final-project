package com.epam.totalizator.command.user.bookmaker;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ShowBookmakerCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) {

        return null;
    }
}
