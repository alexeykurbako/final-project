package com.epam.totalizator.service.user;

import com.epam.totalizator.builder.impl.UserBuilder;
import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.UserDaoImpl;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;


public class UserService {

    private static final Logger LOGGER = LogManager.getLogger(UserService.class);

    public void update(User user) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            UserDaoImpl userDao = factory.getUserDao();
            userDao.update(user);
        }
    }

    public Optional<User> getById(long id) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            UserDaoImpl userDao = factory.getUserDao();
            return userDao.getById(id);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
    }


    public List<User> getAll() throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            UserDaoImpl userDao = factory.getUserDao();
            return userDao.getAll();
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
    }

    public Optional<User> login(String username, String password) throws ServiceException {
        Optional<User> actual = null;
        try (DaoFactory factory = new DaoFactory()) {
            UserDaoImpl dao = factory.getUserDao();
            actual = dao.findUserByLoginAndPassword(username, password);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
        return actual == null ? Optional.empty() : actual;
    }
}
