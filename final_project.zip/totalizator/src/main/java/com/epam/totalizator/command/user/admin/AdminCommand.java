package com.epam.totalizator.command.user.admin;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.user.UserService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class AdminCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
            UserService service = new UserService();
            List<User> list = service.getAll();
            request.setAttribute("usersList", list);
        return new Respond (Respond.FORWARD, "/admin.jsp");
    }
}
