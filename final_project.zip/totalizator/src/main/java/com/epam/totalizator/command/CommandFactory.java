package com.epam.totalizator.command;

import com.epam.totalizator.command.bet.CreateBetCommand;
import com.epam.totalizator.command.bet.ShowAddBetCommand;
import com.epam.totalizator.command.event.AddEventCommand;
import com.epam.totalizator.command.event.FinishEventCommand;
import com.epam.totalizator.command.event.ShowFinishEventCommand;
import com.epam.totalizator.command.user.LogOutCommand;
import com.epam.totalizator.command.user.LoginCommand;
import com.epam.totalizator.command.user.admin.LockUserCommand;
import com.epam.totalizator.command.user.bookmaker.ShowBookmakerAddCommand;
import com.epam.totalizator.command.user.client.ShowUserAccount;

public class CommandFactory {
    public static Command create(String command){
        switch (command){
            case "login":
                return new LoginCommand();
            case "user_account":
                return new ShowUserAccount();
            case "lock_user_command":
                return new LockUserCommand();
            case "create_event":
                return new AddEventCommand();
            case "show_bookmaker_add":
                return new ShowBookmakerAddCommand();
            case "show_add_bet":
                return new ShowAddBetCommand();
            case "create_bet":
                return new CreateBetCommand();
            case "show_finish_event":
                return new ShowFinishEventCommand();
            case "finish_event":
                return new FinishEventCommand();
            case "log_out":
                return new LogOutCommand();
            case "change_language":
                return new ChangeLanguageCommand();
            default:
                throw new IllegalArgumentException("Unknown command " + command);
        }
    }
}
