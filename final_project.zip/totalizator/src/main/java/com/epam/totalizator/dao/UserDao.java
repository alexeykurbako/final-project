package com.epam.totalizator.dao;

import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.DaoException;

import java.util.Optional;

public interface UserDao extends Dao<User> {
    Optional<User> findUserByLoginAndPassword(String login, String password) throws DaoException;
}
