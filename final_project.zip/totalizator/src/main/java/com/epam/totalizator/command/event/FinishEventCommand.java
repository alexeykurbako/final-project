package com.epam.totalizator.command.event;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.helper.BetCalculator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.List;

public class FinishEventCommand implements Command {
    private static final String EVENT_ID_PARAMETER = "event_id";
    private static final String FIRST_TEAM_RESULT_PARAMETER = "first_team_result";
    private static final String SECOND_TEAM_RESULT_PARAMETER = "second_team_result";

    private static final String EVENT_LIST_ATTRIBUTE = "eventsList";
    private static final String BOOKMAKER_PAGE_PATH = "/bookmaker.jsp";
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
        long event_id = Long.parseLong(request.getParameter(EVENT_ID_PARAMETER));
        int firstTeamResult = Integer.parseInt(request.getParameter(FIRST_TEAM_RESULT_PARAMETER));
        int secondTeamResult = Integer.parseInt(request.getParameter(SECOND_TEAM_RESULT_PARAMETER));

        BetCalculator calculator = new BetCalculator();
        calculator.calculateBets( firstTeamResult, secondTeamResult, event_id);

        EventService eventService = new EventService();
        List<Event> activeEvents = eventService.getAllActiveEvents();

        HttpSession session = request.getSession();
        session.setAttribute(EVENT_LIST_ATTRIBUTE, activeEvents);
        return new Respond (Respond.FORWARD, BOOKMAKER_PAGE_PATH);
    }
}
