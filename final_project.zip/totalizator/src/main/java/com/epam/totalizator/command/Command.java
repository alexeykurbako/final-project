package com.epam.totalizator.command;

import com.epam.totalizator.exceptions.ServiceException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public interface Command {
    String NAME = "command";
    Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, IOException, ServletException;
}
