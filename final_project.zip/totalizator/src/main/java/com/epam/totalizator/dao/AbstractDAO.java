package com.epam.totalizator.dao;
import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.epam.totalizator.connection.ConnectionPool;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;


public abstract class AbstractDAO<T> implements Dao<T> {
    protected Connection connection;

    private static final Logger LOGGER = LogManager.getLogger(AbstractDAO.class);

    //protected abstract Map<String, Object> getParameters(T object);

    protected abstract void prepareUpdateStatement(PreparedStatement preparedStatement, String... params) throws DaoException;

    protected abstract void prepareRemoveStatement(PreparedStatement preparedStatement, T object) throws DaoException;

    protected abstract void prepareExecuteStatement(PreparedStatement preparedStatement, String... params) throws DaoException;

    protected abstract void prepareInsertStatement(PreparedStatement preparedStatement, T object) throws DaoException;

    protected List<T> executeQuery(String executeQuery, Builder<T> builder, String... params) throws DaoException {
        try {
            PreparedStatement statement = connection.prepareStatement(executeQuery);
            prepareExecuteStatement(statement, params);
            ResultSet resultSet = statement.executeQuery();
            List<T> entities = new ArrayList<>();
            while (resultSet.next()) {
                T entity = builder.build(resultSet);
                entities.add(entity);
            }
            return entities;
        } catch (SQLException e) {
            throw new DaoException(e);
            //log
        }
    }

    protected void executeUpdate(String updateQuery, String... params) throws DaoException {
        //Map<String, Object> parameters = getParameters(object);
        //Set<Map.Entry<String, Object>> parametersSet = parameters.entrySet();
        //String stringStatement = getInsertStatement();
        try {

            PreparedStatement statement = connection.prepareStatement(updateQuery);
            prepareUpdateStatement(statement, params);
            statement.executeUpdate();
        } catch (SQLException e) {
            LOGGER.error("Exception while updating", e);
            throw new DaoException(e);
        }
    }

    protected void executeInsert(String insertQuery, T object) throws DaoException {
        try {
            PreparedStatement statement = connection.prepareStatement(insertQuery);
            prepareInsertStatement(statement, object);
            statement.executeUpdate();
        } catch (SQLException e) {
            LOGGER.error("Exception while updating", e);
            throw new DaoException(e);
        }
    }


    protected void executeRemove(String removeQuery, T object) throws DaoException {
        try {
            PreparedStatement statement = connection.prepareStatement(removeQuery);
            prepareRemoveStatement(statement, object);
            statement.executeUpdate();
        } catch (SQLException e) {
            LOGGER.error("Exception while removing", e);
            throw new DaoException(e);
        }
    }
}

