package com.epam.totalizator.controller;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.CommandFactory;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.connection.ConnectionPool;
import com.epam.totalizator.dao.impl.TeamDaoImpl;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.ServiceException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class Controller extends HttpServlet {
    private static final Logger LOGGER = LogManager.getLogger (Controller.class);
    @Override
    protected void doGet(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException, ServletException {
        try {
            processRequest(httpServletRequest, httpServletResponse);
        } catch (ServiceException e) {
            e.printStackTrace();
            LOGGER.error("ServiceException in doGet method",e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws IOException, ServletException {
        try {
            processRequest(httpServletRequest, httpServletResponse);
        } catch (ServiceException e) {
            e.printStackTrace();
            LOGGER.error("ServiceException in doPost method",e);
        }
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServiceException, IOException, ServletException {
        response.setContentType("text/html;charset=UTF-8");
        response.setContentType("text/html");

        String commandName = request.getParameter("command");

        CommandFactory commandFactory = new CommandFactory();
        Command command = commandFactory.create(commandName);
        Respond respond = null;
        if (command != null) {
                respond = command.execute(request, response);
            switch (respond.getStatus()) {
                case Respond.FORWARD:
                    RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(respond.getPath());
                    dispatcher.forward(request, response);
                    break;
                case Respond.REDIRECT:
                    response.sendRedirect(respond.getPath());
                    break;
            }
        }
    }

    @Override
    public void destroy() {
            ConnectionPool.getConnectionPool().closeAll();
    }
}