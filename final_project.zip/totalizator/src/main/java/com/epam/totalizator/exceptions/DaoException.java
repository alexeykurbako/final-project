package com.epam.totalizator.exceptions;

public class DaoException extends Throwable {
    public DaoException(Throwable e) { super(e);}
}
