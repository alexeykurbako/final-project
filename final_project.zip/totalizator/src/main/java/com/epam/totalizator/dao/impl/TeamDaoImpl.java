package com.epam.totalizator.dao.impl;

import com.epam.totalizator.builder.impl.TeamBuilder;
import com.epam.totalizator.dao.AbstractDAO;
import com.epam.totalizator.dao.TeamDao;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.DaoException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class TeamDaoImpl extends AbstractDAO<Team> implements TeamDao  {
    private static final Logger LOGGER = LogManager.getLogger (TeamDaoImpl.class);

    private static final String GET_ALL = "SELECT team.team_id ,team.name, category.name, league.name FROM team " +
            "JOIN category ON team.category_id = category.category_id " +
            "JOIN league ON team.league_id = league.league_id";

    private static final String GET_TWO_TEAMS = "SELECT team.team_id ,team.name, category.name, league.name FROM team " +
            "JOIN category ON team.category_id = category.category_id " +
            "JOIN league ON team.league_id = league.league_id " +
            " WHERE team.name = ? OR team.name = ?";

    private static final String GET_BY_NAME = "SELECT team.team_id ,team.name, category.name, league.name FROM team " +
            "JOIN category ON team.category_id = category.category_id " +
            "JOIN league ON team.league_id = league.league_id " +
            "WHERE team.name = ?";

    private static final String GET_BY_ID = "SELECT team.team_id ,team.name, category.name, league.name FROM team " +
            "JOIN category ON team.category_id = category.category_id " +
            "JOIN league ON team.league_id = league.league_id " +
            "WHERE team.team_id = ?";

    private static final String REMOVE_BY_ID = "DELETE team_id,name,category_id,league_id FROM team WHERE team_id = ?";


    public TeamDaoImpl(Connection connection) {
        super.connection = connection;
    }

    @Override
    protected void prepareUpdateStatement(PreparedStatement preparedStatement, String... params) throws DaoException {

    }

    @Override
    protected void prepareRemoveStatement(PreparedStatement preparedStatement, Team object) throws DaoException {
        try {
            preparedStatement.setLong (1, object.getId());
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementUpdate in  implementation of UserDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareExecuteStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
            for(int i = 0; i < params.length; i++){
                preparedStatement.setString (i + 1, params[i]);
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in prepareExecuteStatement in  implementation of TeamDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareInsertStatement(PreparedStatement preparedStatement, Team object) throws DaoException {

    }

    @Override
    public Optional<Team> getById(long id) throws DaoException {
        return null;
    }

    @Override
    public List<Team> getAll() throws DaoException {
        List<Team> list = executeQuery(GET_ALL, new TeamBuilder());
        return list;
    }

    @Override
    public void save(Team object) throws DaoException {

    }

    @Override
    public void removeById(Team object) throws DaoException {
        executeRemove(REMOVE_BY_ID, object);
    }

    @Override
    public List<Team> getBothTeam(String firstTeamName, String secondTeamName) throws DaoException {
        List<Team> list = executeQuery(GET_TWO_TEAMS, new TeamBuilder(), firstTeamName, secondTeamName);
        return list;
    }

    @Override
    public Optional<Team> getTeamByName(String name) throws DaoException {
        List<Team> list = executeQuery(GET_BY_NAME, new TeamBuilder(), name);
        if(list.size() == 0){
            return Optional.empty();
        }else {
            return Optional.ofNullable(list.iterator().next());
        }
    }

    @Override
    public Optional<Team> getTeamById(long id) throws DaoException {
        String teamId = String.valueOf(id);
        List<Team> list = executeQuery(GET_BY_ID, new TeamBuilder(), teamId);
        if(list.size() == 0){
            return Optional.empty();
        }else {
            return Optional.ofNullable(list.iterator().next());
        }
    }
}
