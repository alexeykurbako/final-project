package com.epam.totalizator.builder.impl;

import com.epam.totalizator.builder.Builder;
import com.epam.totalizator.entity.League;
import com.epam.totalizator.entity.Team;

import java.sql.ResultSet;
import java.sql.SQLException;

public class LeagueBuilder implements Builder<League> {
    @Override
    public League build(ResultSet resultSet) throws SQLException {
        long id = resultSet.getLong("league_id");
        String name = resultSet.getString("name");
        return new League(id, name);
    }
}
