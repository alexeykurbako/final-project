package com.epam.totalizator.command.user.client;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.bet.BetService;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.helper.BetView;
import com.epam.totalizator.service.helper.BetViewHelper;
import com.epam.totalizator.service.helper.Result;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class ShowUserAccount implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");
        BetViewHelper betViewHelper = new BetViewHelper();

        List<BetView> betViews = betViewHelper.calculateFinishedBets(currentUser);
        request.setAttribute("betViews", betViews);
        request.getRequestDispatcher("user_account.jsp").forward(request,response);
        return null;
    }
}
