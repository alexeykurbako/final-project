package com.epam.totalizator.command;

public class Respond {
    public static final String FORWARD = "forward";
    public static final String REDIRECT = "redirect";

    private String status;
    private String path;

    public Respond(String status, String path) {
        this.status = status;
        this.path = path;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }


}
