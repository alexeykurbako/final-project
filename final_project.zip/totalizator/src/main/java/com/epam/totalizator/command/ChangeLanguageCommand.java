package com.epam.totalizator.command;

import com.epam.totalizator.exceptions.ServiceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class ChangeLanguageCommand implements Command {

private static final String REFERER = "referer";
    private static final String LANGUAGE = "language";

    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
        HttpSession session = request.getSession ();
        String lang = request.getParameter (LANGUAGE);
        session.setAttribute ("language", lang);
        String lastUrl = request.getHeader (REFERER);
        return new Respond (Respond.REDIRECT, lastUrl);
    }
}
