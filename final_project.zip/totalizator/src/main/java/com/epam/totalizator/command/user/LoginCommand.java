package com.epam.totalizator.command.user;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class LoginCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        UserService service = new UserService();
        Optional<User> actual = service.login(username, password);
        String path = choosePath(actual, request);
        return new Respond (Respond.REDIRECT, path);
    }

    private String choosePath(Optional<User> actual, HttpServletRequest request) throws ServletException, IOException, ServiceException {
        String path = null;
        if(actual.isPresent()) {
            switch (actual.get().getRole()){
                case USER:
                    setUserAttributes(request, actual);
                    path = "/user_main.jsp";
                    break;
                case ADMIN:
                    setAdminAttributes(request, actual);
                    path = "/admin.jsp";
                    break;
                case BOOKMAKER:
                    setBookmakerAttributes(request, actual);
                    path = "/bookmaker.jsp";
                    break;
            }
        } else {
            request.setAttribute("is_valid", "false");
            path = "/index.jsp";
        }
        return path;
    }

    private void setUserAttributes(HttpServletRequest request, Optional<User> actual) throws ServiceException, ServletException, IOException {
        EventService eventService = new EventService();
        HttpSession session = request.getSession();
      //  session.setAttribute("language", Language.EN);
        session.setAttribute ("language", "ru");
        session.setAttribute("user",actual.get());
        List<Event> eventsList = eventService.getAllActiveEvents();
        session.setAttribute("eventsList", eventsList);
    }

    private void setAdminAttributes(HttpServletRequest request, Optional<User> actual) throws ServiceException, ServletException, IOException {
        HttpSession session = request.getSession();
        UserService userService = new UserService();
        session.setAttribute("admin",actual.get());
        List<User> users = userService.getAll();
        request.setAttribute("usersList", users);
    }

    private void setBookmakerAttributes(HttpServletRequest request, Optional<User> actual) throws ServiceException, ServletException, IOException {
        HttpSession session = request.getSession();
        EventService eventService = new EventService();
        List<Event> activeEvents = eventService.getAllActiveEvents();
        session.setAttribute("eventsList", activeEvents);
    }

}
