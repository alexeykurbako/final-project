package com.epam.totalizator.service.bet;

import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.BetDaoImpl;
import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import java.util.List;


public class BetService {
    private static final Logger LOGGER = LogManager.getLogger(BetService.class);

    public void changeBetStatus(Bet bet) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            BetDaoImpl betDao = factory.getBetDao();
            betDao.changeBetStatus(bet);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
    }

    public List<Bet> getNotPayedBets() throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            BetDaoImpl betDao = factory.getBetDao();
            return betDao.getNotPayedBets();
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Failed login",e);
        }
    }

    public void save(Bet bet) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            BetDaoImpl betDao = factory.getBetDao();
            betDao.save(bet);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Fail while saving a bet",e);
        }
    }

    public List<Bet> getBetsByFinishedEvents(User user) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            BetDaoImpl betDao = factory.getBetDao();
            return betDao.getBetsByFinishedEvents(user);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Fail while saving a bet",e);
        }
    }
}
