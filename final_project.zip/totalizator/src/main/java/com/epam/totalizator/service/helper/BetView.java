package com.epam.totalizator.service.helper;

import com.epam.totalizator.entity.Category;
import com.epam.totalizator.entity.Team;

import java.math.BigDecimal;
import java.util.Objects;



public class BetView {
    Category category;
    Team team;
    double coef;
    BigDecimal size;
    Result result;

    public BetView(Category category, Team team, double coef, BigDecimal size, Result result) {
        this.category = category;
        this.team = team;
        this.coef = coef;
        this.size = size;
        this.result = result;
    }

    public Category getCategory() {
        return category;
    }

    public Team getTeam() {
        return team;
    }

    public double getCoef() {
        return coef;
    }

    public BigDecimal getSize() {
        return size;
    }

    public Result getResult() {
        return result;
    }

    public void setCategory(Category category) {
        this.category = category;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public void setCoef(double coef) {
        this.coef = coef;
    }

    public void setSize(BigDecimal size) {
        this.size = size;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BetView that = (BetView) o;
        return Double.compare(that.coef, coef) == 0 &&
                category == that.category &&
                Objects.equals(team, that.team) &&
                Objects.equals(size, that.size) &&
                result == that.result;
    }

    @Override
    public int hashCode() {
        return Objects.hash(category, team, coef, size, result);
    }
}
