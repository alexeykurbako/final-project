package com.epam.totalizator.service.event;

import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.BetDaoImpl;
import com.epam.totalizator.dao.impl.EventDaoImpl;
import com.epam.totalizator.dao.impl.UserDaoImpl;
import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.util.List;
import java.util.Optional;

public class EventService {
    private static final Logger LOGGER = LogManager.getLogger(EventService.class);

    public Optional<Event> getEventByUserIdAndEventId(long event_id, long currentUserId) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            EventDaoImpl eventDao = factory.getEventDao();
            return eventDao.getEventByUserIdAndEventId(event_id, currentUserId);
        }
    }

    public void save(Event event) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            EventDaoImpl eventDao = factory.getEventDao();
            eventDao.save(event);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Save failed",e);
        }
    }

    public Optional<Event> getById(long id) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            EventDaoImpl eventDao = factory.getEventDao();
            return eventDao.getById(id);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public List<Event> getAll() throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
          EventDaoImpl eventDao = factory.getEventDao();
            return eventDao.getAll();
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public void finishEvent(int firstTeamResult, int secondTeamResult, long event_id) throws ServiceException {
        try(DaoFactory factory = new DaoFactory()) {
            EventDaoImpl dao = factory.getEventDao();
            String firstTeamParam = String.valueOf(firstTeamResult);
            String secondTeamParam = String.valueOf(secondTeamResult);
            String idParam = String.valueOf(event_id);
            dao.finishEvent(firstTeamParam, secondTeamParam, idParam);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Finish event failed",e);
        }
    }

    public List<Event> getAllActiveEvents() throws ServiceException {
        try(DaoFactory factory = new DaoFactory()) {
            EventDaoImpl dao = factory.getEventDao();
            return dao.getAllActiveEvents();
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query failed",e);
        }
    }

    public List<Event> getFinishedEventsByUser(User user) throws ServiceException {
        try (DaoFactory factory = new DaoFactory()) {
            EventDaoImpl eventDao = factory.getEventDao();
            return eventDao.getFinishedEventByUser(user);
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Query was failed",e);
        }
    }




}
