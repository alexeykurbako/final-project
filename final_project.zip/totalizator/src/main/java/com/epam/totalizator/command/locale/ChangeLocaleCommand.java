package com.epam.totalizator.command.locale;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class ChangeLocaleCommand implements Command {

    private static final String REFERER = "referer";
    private static final String LANGUAGE = "language";

    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession ();
        session.setAttribute (LANGUAGE, request.getParameter (LANGUAGE));
        String lastUrl = request.getHeader (REFERER);
        return new Respond (Respond.REDIRECT, lastUrl);
    }
}