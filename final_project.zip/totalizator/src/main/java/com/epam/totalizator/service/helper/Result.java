package com.epam.totalizator.service.helper;

public enum Result{
    WIN("WIN"), DRAW("DRAW"), DEFEAT("DEFEAT");
    private String value;

    Result(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}