package com.epam.totalizator.dao;

import com.epam.totalizator.dao.Dao;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.DaoException;

import java.util.List;
import java.util.Optional;

public interface TeamDao extends Dao<Team> {
    List<Team> getBothTeam(String firstTeamName, String secondTeamName) throws DaoException;
    Optional<Team> getTeamByName(String name) throws DaoException;
    Optional<Team> getTeamById(long id) throws DaoException;
}
