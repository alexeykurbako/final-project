package com.epam.totalizator.service.helper;

import com.epam.totalizator.entity.*;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.bet.BetService;
import com.epam.totalizator.service.competition.CompetitionService;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.team.TeamService;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class BetViewHelper {
    public List<BetView> calculateFinishedBets(User user) throws ServiceException {
        EventService eventService = new EventService();
        BetService betService = new BetService();
        List<Event> eventList = eventService.getFinishedEventsByUser(user);
        List<Bet> betList = betService.getBetsByFinishedEvents(user);
        List<BetView> views = new ArrayList<>();
        int i = 0;
        for(Bet bet: betList){
            Event currenEvent = eventList.get(i);
            Category category = currenEvent.getCompetition().getFirstTeam().getCategory();
            Team team = calculateTeam(currenEvent, bet);
            double coef = calculateCoef(currenEvent, bet);
            BigDecimal size = bet.getSize();
            Result result = calculateResult(currenEvent, bet);
            views.add(new BetView(category, team, coef, size, result));
            i++;
        }
        return views;
    }

    private double calculateCoef(Event event, Bet currentBet) throws ServiceException {
        double coef = 0;
        TeamService teamService = new TeamService();
        Optional<Team> betTeam = teamService.getTeamById(currentBet.getChosenTeamId());
        if(betTeam.isPresent()){
            Team actualTeam = betTeam.get();
            Team firstTeam = event.getCompetition().getFirstTeam();
            String currentTeamName = actualTeam.getTeamName();
            String firstTeamName = firstTeam.getTeamName();
            coef = firstTeamName.equals(currentTeamName) ? event.getFirstTeamCoefficient() : event.getSecondTeamCoefficient();
        }
        return coef;
    }

    private Team calculateTeam(Event event, Bet currentBet) throws ServiceException {
        TeamService teamService = new TeamService();
        Team chosenTeam = null;
        Optional<Team> betTeam = teamService.getTeamById(currentBet.getChosenTeamId());
        if(betTeam.isPresent()){
            Team actualTeam = betTeam.get();
            Team firstTeam = event.getCompetition().getFirstTeam();
            Team secondTeam = event.getCompetition().getSecondTeam();
            String currentTeamName = actualTeam.getTeamName();
            String firstTeamName = firstTeam.getTeamName();
            chosenTeam = firstTeamName.equals(currentTeamName) ? firstTeam : secondTeam;
        }
        return chosenTeam;
    }

    private Result calculateResult(Event event, Bet currentBet) throws ServiceException {

        TeamService teamService = new TeamService();
        Optional<Team> betTeam = teamService.getTeamById(currentBet.getChosenTeamId());
        Result result = null;
        if(betTeam.isPresent()){
            Team actualTeam = betTeam.get();
            String firstTeamName = event.getCompetition().getFirstTeam().getTeamName();
            String secondTeamName = event.getCompetition().getSecondTeam().getTeamName();
            String currentTeamName = actualTeam.getTeamName();

            CompetitionService competitionService = new CompetitionService();
            Optional<Competition> competition = competitionService.getCompetitionByTeams(firstTeamName,secondTeamName);
            int firstTeamResult = competition.get().getFirstTeamScore();
            int secondTeamResult = competition.get().getSecondTeamScore();

            if(firstTeamResult > secondTeamResult && firstTeamName.equals(currentTeamName) ||
                    firstTeamResult < secondTeamResult && secondTeamName.equals(currentTeamName)){
                result = Result.WIN;
            } else if(firstTeamResult == secondTeamResult){
                result = Result.DRAW;
            } else {
                result = Result.DEFEAT;
            }

        }
        return result;
    }
}
