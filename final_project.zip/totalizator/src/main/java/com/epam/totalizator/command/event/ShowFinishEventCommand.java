package com.epam.totalizator.command.event;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;

public class ShowFinishEventCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException {
        long id = Long.parseLong(request.getParameter("event_id"));
        EventService eventService = new EventService();
        Optional<Event> actual = eventService.getById(id);
        actual.ifPresent(event -> {
            Competition competition = event.getCompetition();
            Team firstTeam = competition.getFirstTeam();
            Team secondTeam = competition.getSecondTeam();

            request.setAttribute("event", event);
            request.setAttribute("first_team", firstTeam);
            request.setAttribute("second_team", secondTeam);

        });
        return new Respond (Respond.FORWARD, "/finish_event.jsp");
    }
}