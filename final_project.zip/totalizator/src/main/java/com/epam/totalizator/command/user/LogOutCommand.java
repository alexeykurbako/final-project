package com.epam.totalizator.command.user;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class LogOutCommand implements Command {

    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        session.invalidate();
        return new Respond (Respond.FORWARD, "/index.jsp");
    }
}
