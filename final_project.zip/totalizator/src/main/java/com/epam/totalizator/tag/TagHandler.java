package com.epam.totalizator.tag;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class TagHandler extends TagSupport {
    private static final Logger LOGGER = LogManager.getLogger(TagHandler.class);

//    private static final String LANGUAGE_ATTRIBUTE = "language";
//
//    private static final String RU_PATTERN = "dd MMMM yyyy HH:mm";
//
//    private LocalDateTime date;
//
//    public void setDate(LocalDateTime date) {
//        this.date = date;
//    }
//    Locale locale = Locale.forLanguageTag("ru");
//    @Override
//    public int doStartTag() throws JspException {
//
//        DateTimeFormatter formatter = DateTimeFormatter
//                .ofPattern(RU_PATTERN)
//                .withLocale(locale);
//
//        String formattedDate = date.format(formatter);
//        JspWriter out = pageContext.getOut();
//        try {
//            out.write(formattedDate);
//        } catch (IOException e) {
//            LOGGER.error(e);
//            throw new JspException(e);
//        }
//        return SKIP_BODY;
//    }
    @Override
    public int doStartTag() throws JspException {
        try {
            pageContext.getOut().print("&copy; Shkila");
        } catch (IOException exc) {
            LOGGER.error(exc);
            throw new JspException("Error: " + exc.getMessage());
        }
        return SKIP_BODY;
    }
}
