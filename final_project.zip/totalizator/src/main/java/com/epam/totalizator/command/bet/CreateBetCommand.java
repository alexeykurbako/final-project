package com.epam.totalizator.command.bet;
import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.bet.BetService;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.helper.BetCreateHelper;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public class CreateBetCommand implements Command {
    private static final Logger LOGGER = LogManager.getLogger(CreateBetCommand.class);
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException {

        long eventId = Long.parseLong(request.getParameter("event_id"));
        long userId = Long.parseLong(request.getParameter("user_id"));
        String firstTeamName = request.getParameter("first_team_name");
        String secondTeamName = request.getParameter("second_team_name");
        int number = Integer.parseInt(request.getParameter("team_number"));
        String path = null;
        BigDecimal size = new BigDecimal(request.getParameter("size"));
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        BetCreateHelper helper = new BetCreateHelper();
        if(helper.createBet(user, size, userId, eventId, firstTeamName, secondTeamName, number)){
            redirectMainPage(request);
            path = "/user_main.jsp";
        } else {
            redirectBetPage(eventId, request);
            path = "/user_create_bet.jsp";
        }
        return new Respond (Respond.FORWARD, path);
    }

    private void redirectMainPage(HttpServletRequest request) throws ServiceException {
        EventService eventService = new EventService();
        List<Event> eventsList = eventService.getAllActiveEvents();
        request.setAttribute("eventsList", eventsList);
    }

    private void redirectBetPage(long eventId, HttpServletRequest request) throws ServiceException {
        EventService eventService = new EventService();
        Optional<Event> actual = eventService.getById(eventId);
        actual.ifPresent(event -> {
            Competition competition = event.getCompetition();
            Team firstTeam = competition.getFirstTeam();
            Team secondTeam = competition.getSecondTeam();
            double firstCoef = event.getFirstTeamCoefficient();
            double secondCoef = event.getSecondTeamCoefficient();

            request.setAttribute("event", event);
            request.setAttribute("first_team", firstTeam);
            request.setAttribute("second_team", secondTeam);
            request.setAttribute("first_coef", firstCoef);
            request.setAttribute("second_coef", secondCoef);
            request.setAttribute("isValid", false);
        });
    }
}
