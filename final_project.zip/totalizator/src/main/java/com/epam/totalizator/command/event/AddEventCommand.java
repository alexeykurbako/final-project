package com.epam.totalizator.command.event;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.team.TeamService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class AddEventCommand implements Command {
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException, ServletException, IOException {
        TeamService teamService = new TeamService();

        String firstTeamName = request.getParameter("first_team");
        String secondTeamName = request.getParameter("second_team");
        Optional<Team> firstTeam = teamService.getTeamByName(firstTeamName);
        Optional<Team> secondTeam = teamService.getTeamByName(secondTeamName);

        Competition competition = new Competition(0, firstTeam.get(), secondTeam.get(),"new",0,0);

        double firstCoefficient = Double.parseDouble(request.getParameter("first_koef"));
        double secondCoefficient = Double.parseDouble(request.getParameter("second_koef"));
        Event event = new Event(0, competition, firstCoefficient, secondCoefficient);

        EventService eventService = new EventService();
        eventService.save(event);

        return new Respond (Respond.FORWARD, "/bookmaker.jsp");
    }
}

