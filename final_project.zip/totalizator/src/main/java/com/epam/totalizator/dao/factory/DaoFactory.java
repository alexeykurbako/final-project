package com.epam.totalizator.dao.factory;

import com.epam.totalizator.connection.ConnectionPool;
import com.epam.totalizator.dao.impl.*;

import java.sql.Connection;

public class DaoFactory implements AutoCloseable {
    private Connection connection;

    public DaoFactory(){
        this.connection = ConnectionPool.getConnectionPool().getConnection();
    }

    public BetDaoImpl getBetDao(){
        return new BetDaoImpl(connection);
    }

    public CompetitionDaoImpl getCompetitionDao(){
        return new CompetitionDaoImpl(connection);
    }

    public EventDaoImpl getEventDao(){
        return new EventDaoImpl(connection);
    }

    public TeamDaoImpl getTeamDao(){
        return new TeamDaoImpl(connection);
    }

    public UserDaoImpl getUserDao(){
        return new UserDaoImpl(connection);
    }

    @Override
    public void close() {
        ConnectionPool.getConnectionPool().returnConnectionToPool(connection);
    }
}
