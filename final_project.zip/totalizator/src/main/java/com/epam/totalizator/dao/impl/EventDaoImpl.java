package com.epam.totalizator.dao.impl;

import com.epam.totalizator.builder.impl.BetBuilder;
import com.epam.totalizator.builder.impl.EventBuilder;
import com.epam.totalizator.builder.impl.UserBuilder;
import com.epam.totalizator.dao.AbstractDAO;
import com.epam.totalizator.dao.EventDao;
import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.competition.CompetitionService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class EventDaoImpl extends AbstractDAO<Event> implements EventDao {
    private static final Logger LOGGER = LogManager.getLogger (EventDaoImpl.class);

    private static final String GET_ALL_QUERY = "SELECT * FROM totalizator.event";

    private static final String GET_ALL_ACTIVE_EVENTS = "SELECT event_id, category.name, t1.name, t2.name, first_team_coefficient, second_team_coefficient, l1.name, l2.name FROM " +
            "event JOIN competition ON competition.competition_id = event.competition_id " +
            "JOIN team t1 ON competition.first_team_id = t1.team_id " +
            "JOIN team t2 ON competition.second_team_id = t2.team_id " +
            "JOIN category on t1.category_id = category.category_id " +
            "JOIN league l1 on t1.league_id = l1.league_id " +
            "JOIN league l2 on t2.league_id = l2.league_id " +
            "WHERE competition.status ='new'";

    private static final String GET_EVENT_BY_ID = "SELECT event_id, category.name, t1.name, t2.name, first_team_coefficient, second_team_coefficient, l1.name, l2.name FROM " +
            "event JOIN competition ON competition.competition_id = event.competition_id " +
            "JOIN team t1 ON competition.first_team_id = t1.team_id " +
            "JOIN team t2 ON competition.second_team_id = t2.team_id " +
            "JOIN category on t1.category_id = category.category_id " +
            "JOIN league l1 on t1.league_id = l1.league_id " +
            "JOIN league l2 on t2.league_id = l2.league_id " +
            "WHERE event_id = ?";

    private static final String FINISH_EVENT = "UPDATE totalizator.competition SET competition.status = 'finish', competition.team_first_result = ?, competition.team_second_result = ? " +
                        "WHERE competition_id = (SELECT competition_id FROM event WHERE event_id = ?)";

    private static final String INSERT_QUERY = "INSERT INTO totalizator.event(competition_id, first_team_coefficient, second_team_coefficient)" +
            " values ((SELECT MAX(competition_id) FROM totalizator.competition),?,?)";

    private static final String GET_EVENT_BY_USER_ID_AND_EVENT_ID = "SELECT event.event_id, category.name, t1.name, t2.name, first_team_coefficient, second_team_coefficient, l1.name, l2.name " +
            "FROM event JOIN bet b on event.event_id = b.event_id " +
            " JOIN competition ON competition.competition_id = event.competition_id " +
            " JOIN team t1 ON competition.first_team_id = t1.team_id " +
            " JOIN team t2 ON competition.second_team_id = t2.team_id " +
            " JOIN category on t1.category_id = category.category_id " +
            " JOIN league l1 on t1.league_id = l1.league_id " +
            " JOIN league l2 on t2.league_id = l2.league_id " +
            "  where b.event_id = ? AND b.user_id = ?; ";

    private static final String REMOVE_BY_ID = "DELETE event_id, competition_id, first_team_coefficient, second_team_coefficient FROM totalizator.event WHERE event_id = ?";

    private final static String GET_FINISHED_EVENT_BY_USER_ID = "SELECT event.event_id, category.name, t1.name, t2.name, first_team_coefficient, second_team_coefficient, l1.name, l2.name FROM " +
            "event JOIN competition ON competition.competition_id = event.competition_id " +
            "JOIN team t1 ON competition.first_team_id = t1.team_id " +
            "JOIN team t2 ON competition.second_team_id = t2.team_id " +
            "JOIN category on t1.category_id = category.category_id " +
            "JOIN league l1 on t1.league_id = l1.league_id " +
            "JOIN league l2 on t2.league_id = l2.league_id " +
            "JOIN bet b on event.event_id = b.event_id " +
            "WHERE competition.status ='finish' and b.user_id = ?;";

    public EventDaoImpl(Connection connection) {
        super.connection = connection;
    }

    @Override
    protected void prepareUpdateStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
//            preparedStatement.setInt (1, Integer.parseInt(params[0]));
//            preparedStatement.setInt(2, Integer.parseInt(params[1]));
//            preparedStatement.setLong(3, Long.parseLong(params[2]));
            if(params.length != 0) {
                for(int i = 0; i < params.length; i++){
                    preparedStatement.setString (i + 1, params[i]);
                }
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementInserts in  implementation of CompetitionDao class ", e);
        }
    }

    @Override
    protected void prepareRemoveStatement(PreparedStatement preparedStatement, Event object) throws DaoException {
        try {
            preparedStatement.setLong (1, object.getId());
        } catch (SQLException e) {
            LOGGER.error ("exception in prepareRemoveStatement in  implementation of EventDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareExecuteStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
            if(params.length != 0) {
                for(int i = 0; i < params.length; i++){
                    preparedStatement.setString (i + 1, params[i]);
                }
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementInserts in  implementation of EventDao class ", e);
        }
    }

    @Override
    protected void prepareInsertStatement(PreparedStatement preparedStatement, Event object) throws DaoException {
        try {
            preparedStatement.setDouble (1, object.getFirstTeamCoefficient());
            preparedStatement.setDouble (2, object.getFirstTeamCoefficient());
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementInserts in  implementation of EventDao class ", e);
        }
    }


    @Override
    public Optional<Event> getById(long id) throws DaoException {
        List<Event> list = executeQuery(GET_EVENT_BY_ID, new EventBuilder(), String.valueOf(id));
        if(list.size () == 0){
            return Optional.empty();
        }else {
            return Optional.ofNullable(list.iterator().next());
        }
    }

    @Override
    public List<Event> getAll() throws DaoException {
        List<Event> list = executeQuery(GET_ALL_QUERY, new EventBuilder());
        return list;
    }

    @Override
    public void save(Event object) throws DaoException {
        CompetitionService service = new CompetitionService();
        try {
            service.saveCompetition(object.getCompetition());
        } catch (ServiceException e) {
            throw new DaoException(e);
        }

        executeInsert(INSERT_QUERY, object);
    }

    @Override
    public void removeById(Event object) throws DaoException {
        executeRemove(REMOVE_BY_ID, object);
    }

    @Override
    public List<Event> getAllActiveEvents() throws DaoException {
        List<Event> list = executeQuery(GET_ALL_ACTIVE_EVENTS, new EventBuilder());
        return list;
    }

    @Override
    public Optional<Event> getEventByUserIdAndEventId(long eventId, long userId) throws ServiceException {
        List<Event> list;
        try {
            String currentEventId = String.valueOf(eventId);
            String currentUserId = String.valueOf(userId);
            list = executeQuery(GET_EVENT_BY_USER_ID_AND_EVENT_ID, new EventBuilder(),currentEventId, currentUserId);
        } catch (DaoException e) {
            throw new ServiceException("exception in EventDaoImpl", e);
        }
        if(list.size () == 0){
            return Optional.empty();
        }else {
            return Optional.ofNullable(list.iterator().next());
        }
    }

    @Override
    public void finishEvent(String... params) throws DaoException {
        executeUpdate(FINISH_EVENT, params);
    }

    @Override
    public List<Event> getFinishedEventByUser(User user) throws DaoException {
        String userId = String.valueOf(user.getId());
        List<Event> list = executeQuery(GET_FINISHED_EVENT_BY_USER_ID, new EventBuilder(), userId);
        return list;
    }
}

