package com.epam.totalizator.command.user.admin;

import com.epam.totalizator.command.Command;
import com.epam.totalizator.command.Respond;
import com.epam.totalizator.dao.impl.UserDaoImpl;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.helper.UserHelper;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

public class LockUserCommand implements Command {
    private static final Logger LOGGER = LogManager.getLogger (LockUserCommand.class);
    @Override
    public Respond execute(HttpServletRequest request, HttpServletResponse response) throws ServiceException{
        long id = Integer.parseInt(request.getParameter("lock_id"));
        UserService service = new UserService();
        UserHelper helper = new UserHelper();
        helper.lockAction(id);
        List<User> updatedList = service.getAll();
        request.setAttribute("usersList", updatedList);
        return new Respond (Respond.FORWARD, "/admin.jsp");
    }
}
