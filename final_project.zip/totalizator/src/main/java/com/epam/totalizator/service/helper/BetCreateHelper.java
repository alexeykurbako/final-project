package com.epam.totalizator.service.helper;

import com.epam.totalizator.command.bet.CreateBetCommand;
import com.epam.totalizator.dao.factory.DaoFactory;
import com.epam.totalizator.dao.impl.BetDaoImpl;
import com.epam.totalizator.dao.impl.EventDaoImpl;
import com.epam.totalizator.dao.impl.TeamDaoImpl;
import com.epam.totalizator.entity.Bet;
import com.epam.totalizator.entity.Event;
import com.epam.totalizator.entity.Team;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.ConnectionException;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import com.epam.totalizator.service.bet.BetService;
import com.epam.totalizator.service.event.EventService;
import com.epam.totalizator.service.user.UserService;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import java.math.BigDecimal;
import java.util.Optional;

public class BetCreateHelper {
    private static final Logger LOGGER = LogManager.getLogger(BetCreateHelper.class);

    public boolean createBet(User user, BigDecimal size, Long userId, long eventId, String firstTeamName, String secondTeamName, int number) throws ServiceException, ServletException {
        if (isBetValid(user, size)) {
            create(user, size, userId, eventId, firstTeamName, secondTeamName, number);
            return true;
        }
        return false;
    }

    private void create(User user, BigDecimal size, Long userId, long eventId, String firstTeamName, String secondTeamName, int number) throws ServiceException {
        EventService eventService = new EventService();
        BetService betService = new BetService();
        Optional<Event> actual = eventService.getById(eventId);
        actual.ifPresent(event -> {
            try {
                long teamId = defineTeam(firstTeamName, secondTeamName, number);
                Bet bet = new Bet(0, userId, eventId, teamId, size);
                betService.save(bet);
            }  catch (ServiceException e) {
                LOGGER.error(e.getMessage());
            }
        });
        UserHelper helper = new UserHelper();
        helper.subtractBetSize(user, size);
    }

    private long defineTeam(String firstTeamName, String secondTeamName, int number) throws ServiceException {
        long chosenTeamId = 0;

        try(DaoFactory factory = new DaoFactory()){
            Optional<Team> actualChosenTeam;
            TeamDaoImpl teamDao = factory.getTeamDao();
            if(number == 1){
                actualChosenTeam = teamDao.getTeamByName(firstTeamName);
            } else {
                actualChosenTeam = teamDao.getTeamByName(secondTeamName);
            }
            if(actualChosenTeam.isPresent()){
                chosenTeamId = actualChosenTeam.get().getId();
            }
        } catch (DaoException e) {
            LOGGER.error(e.getMessage());
            throw new ServiceException("Team defining failed",e);
        }
        return chosenTeamId;
    }

    private boolean isBetValid(User user, BigDecimal size){
        BigDecimal userAccount = user.getMoney();
        return userAccount.compareTo(size) > 0;
    }
}
