package com.epam.totalizator.dao.impl;

import com.epam.totalizator.builder.impl.BetBuilder;
import com.epam.totalizator.connection.ConnectionPool;
import com.epam.totalizator.dao.AbstractDAO;
import com.epam.totalizator.dao.BetDao;
import com.epam.totalizator.entity.Competition;
import com.epam.totalizator.entity.User;
import com.epam.totalizator.exceptions.DaoException;
import com.epam.totalizator.exceptions.ServiceException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.epam.totalizator.entity.Bet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class BetDaoImpl extends AbstractDAO<Bet> implements BetDao {

    private static final Logger LOGGER = LogManager.getLogger (UserDaoImpl.class);
    private final static String INSERT_QUERY = "INSERT into totalizator.bet (user_id,event_id, team_id, size)" +
            " VALUE (?, ?, ?, ?)";
    private final static String GET_ALL_QUERY = "SELECT * FROM totalizator.bet";
       private final static String GET_NOT_PAYED_BET = "SELECT bet_id, user_id, bet.event_id, team_id, size FROM bet " +
            "JOIN event eve on bet.event_id = eve.event_id " +
            "JOIN competition comp on eve.competition_id = comp.competition_id " +
            "WHERE status = 'finish' AND was_payed = 'false'";
    private final static String REMOVE_BY_ID = "DELETE FROM bet WHERE bet_id = ?;";
    private final static String CHANGE_BET_STATUS = "UPDATE bet SET bet.was_payed = 'true' WHERE bet_id = ?";
    private final static String GET_BETS_BY_FINISHED_EVENT = "SELECT bet.* from bet " +
            "JOIN event e on bet.event_id = e.event_id " +
            "JOIN competition c on e.competition_id = c.competition_id " +
            "WHERE bet.user_id = ? and c.status = 'finish';";


    public BetDaoImpl(Connection connection) {
        super.connection = connection;
    }


    @Override
    protected void prepareUpdateStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
            for(int i = 0; i < params.length; i++){
                preparedStatement.setString (i + 1, params[i]);
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementUpdate in  implementation of BetDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareRemoveStatement(PreparedStatement preparedStatement, Bet object) throws DaoException {
        try {
            preparedStatement.setLong(1, object.getId());
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementUpdate in  implementation of BetDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    protected void prepareExecuteStatement(PreparedStatement preparedStatement, String... params) throws DaoException {
        try {
            for(int i = 0; i < params.length; i++) {
                preparedStatement.setString(i + 1, params[i]);
            }
        } catch (SQLException e) {
            LOGGER.error ("exception in prepareExecuteStatement in  implementation of BetDao class ", e);
            throw new DaoException (e);
        }
    }


    @Override
    protected void prepareInsertStatement(PreparedStatement preparedStatement, Bet object) throws DaoException {
        try {
            preparedStatement.setLong(1, object.getUserId());
            preparedStatement.setLong(2, object.getEventId());
            preparedStatement.setLong(3, object.getChosenTeamId());
            preparedStatement.setBigDecimal(4, object.getSize());
        } catch (SQLException e) {
            LOGGER.error ("exception in preparedStatementUpdate in  implementation of BetDao class ", e);
            throw new DaoException (e);
        }
    }

    @Override
    public Optional<Bet> getById(long id) throws DaoException {
        return Optional.empty();
    }

    @Override
    public List<Bet> getAll() throws DaoException {
        List<Bet> list = executeQuery(GET_ALL_QUERY, null);
        return list;
    }

    @Override
    public void save(Bet object) throws DaoException {
        executeInsert(INSERT_QUERY, object);
    }

    @Override
    public void removeById(Bet object) throws DaoException {
        executeRemove(REMOVE_BY_ID, object);
    }


    @Override
    public List<Bet> getNotPayedBets() throws DaoException {
        List<Bet> list = executeQuery(GET_NOT_PAYED_BET, new BetBuilder());
        return list;
    }

    @Override
    public void changeBetStatus(Bet bet) throws DaoException {
        String betId = String.valueOf(bet.getId());
            executeUpdate(CHANGE_BET_STATUS, betId);
    }

    @Override
    public List<Bet> getBetsByFinishedEvents(User user) throws DaoException {
        String userId = String.valueOf(user.getId());
        List<Bet> list = executeQuery(GET_BETS_BY_FINISHED_EVENT, new BetBuilder(), userId);
        return list;
    }
}
