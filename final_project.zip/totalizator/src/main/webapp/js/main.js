
$(window).bind('scroll', function (e) {
	headerOpacity();
});

function headerOpacity() {
  let scrolled = $(window).scrollTop();
  if (scrolled > 10) {
    $('header').css({
      opacity: 1.0 - scrolled * 0.0016
    });
  }
  else{
    $('header').css({
      opacity: 1.0
      });
  }
};
//follow box
$('.menu-btn').on('click', function(e) {
  e.preventDefault();
  $(this).toggleClass('menu-btn_active');
  $('.menu').toggleClass('menu_active');
  $('.title').toggleClass('title_active');
});

//active block
$('.card').on('click', function(e) {
  e.preventDefault();
  $('.some').toggleClass('some_act');
});

$('.close_button').on('click', function(e){
  e.preventDefault();
  $('.some').toggleClass('some_act');
});
