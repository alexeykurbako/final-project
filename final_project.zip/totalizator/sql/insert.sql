insert into category (name) value ("football");
insert into category (name) value ("hockey");
insert into category (name) value ("basketball");
insert into category (name) value ("mma");

insert into totalizator.user (login,email,password,money,role,is_locked)
values
       ("alex","alex@gmail.com","1234",123,"USER","false"),
       ("admin","admin@gmail.com","12345",0,"ADMIN","false"),
       ("bookmaker","bookmaker@gmail.com","12345",0,"BOOKMAKER","false"),
       ("sanya","sanya@gmail.com","12345",0,"USER","false");

insert into totalizator.team(name, category_id)
values
       ("Real Madrid",1),("Barselona",1),("Deportivo",1),("Liverpool",1),("Ajax Amsterdam",1),
       ("CHL",2),("Metallurg",2),("AK Bars",2),("Bern",2),("Comet",2),
       ("Lakers",3),("CSKA",3),("Boston",3),("Golden State",3),("Miami",3),
       ("Brazil",4),("Poland",4),("USA",4),("Italy",4),("Russia",4);


insert into totalizator.competition(first_team_id,second_team_id)
 values
	  (1,3),
    (6,8),
    (13,14),
    (16,18);

insert into league (category_id , name)
	values
		("Spain"),
		("Seria A"),
		("APL"),
		("NHL"),
		("KHL"),
		("NBA");