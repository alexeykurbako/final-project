create database totalizator DEFAULT CHARACTER SET utf8;
use totalizator;

create table category (
	category_id bigint not null auto_increment,
    name varchar(30) not null,
    primary key (category_id)
);
create table league (
	league_id bigint not null auto_increment,
  name varchar(30) not null,
  primary key (league_id)
);

create table team(
  team_id bigint not null auto_increment,
  name varchar(30) not null,
  category_id bigint not null,
  league_id bigint not null,
  primary key (team_id),
  foreign key (category_id) references category(category_id),
  foreign key (league_id) references league(league_id)
);

create table competition(
  competition_id bigint not null auto_increment,
  first_team_id bigint not null,
  second_team_id bigint not null,
  status varchar(10) not null default 'new',
  first_team_result int(3) default 0,
  second_team_result int(3) default 0,
  primary key (competition_id),
  foreign key (first_team_id) references team(team_id),
  foreign key (second_team_id) references team(team_id)

);

create table event(
  event_id bigint not null auto_increment,
  competition_id bigint not null,
  first_team_coefficient double default 2,
  second_team_coefficient double default 2,
  primary key (event_id),
  foreign key (competition_id) references competition(competition_id)
);

create table bet (
  bet_id bigint not null auto_increment,
  user_id bigint not null,
  event_id bigint not null,
  team_id bigint default null,
  bet_size double not null,
  primary key (bet_id),
  foreign key (event_id) references event(event_id),
  foreign key (user_id) references user(user_id),
  foreign key (team_id) references team(team_id)
);

create table user (
	user_id bigint not null auto_increment,
    login varchar(20) not null unique,
    email varchar(30) not null unique,
    password varchar(255) not null,
    money double default 0,
    role varchar(20) default 'user',
    is_locked varchar(5) default 'false',
    primary key (user_id)
);


drop table bet;
drop table user;
drop table category;








